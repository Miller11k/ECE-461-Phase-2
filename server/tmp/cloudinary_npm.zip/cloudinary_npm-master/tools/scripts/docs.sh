#!/bin/bash
jsdoc -d docs -r -p lib/*
