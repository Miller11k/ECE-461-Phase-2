#!/bin/bash
set -e;

eslint ./test ./lib
